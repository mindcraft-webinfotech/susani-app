class AppSizes {
  static const double PAGE_PADDING = 16.0;
  static const double FONT_SIZE = 1.0;
}

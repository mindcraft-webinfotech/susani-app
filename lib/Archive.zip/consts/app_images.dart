class AppImages {
  static const String APP_LOGO = "assets/images/lsd.png";
  static const String NEWS_ICON = "assets/icon/news.png";
  static const String PRODUCT_ICON = "assets/icon/product.png";
}

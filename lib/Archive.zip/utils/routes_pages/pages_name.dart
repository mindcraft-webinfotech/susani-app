class MyPagesName {
  static const String splashFile = "/splash";
  static const String dashBoard = "/dashboard";
  static const String myOrders = "/myorders";
  static const String myFavourites = "/favourite";
  static const String shippingAddress = "/shippingAddress";
  static const String giftCards = "/giftCards";
  static const String savedCards = "/savedCards";
  static const String editProfile = "/editProfile";
  static const String newsfullpage = "/newsfullpage";
  static const String productFullView = "/productFullViewPage";
  static const String category_product = "/category_product";
  static const String checkoutPage = "/checkoutPage";
  static const String ecom_checkoutPage = "/ecom_checkoutPage";
  static const String SignUp = "/SignUp";
  static const String SignIn = "/Signin";
  static const String OrderSuccess = "/OrderSuccess";
  static const String DonationPage = "/DonationPage";
  static const String CalenderPage = "/CalenderPage";
  static const String MyWebView = "/MyWebView";
  static const String ContctUs = "/ContactUs";
}

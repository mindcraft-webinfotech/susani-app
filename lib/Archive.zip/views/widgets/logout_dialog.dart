import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class LogoutPopup {
  BuildContext context;

  LogoutPopup({required this.context});

  Widget get dialog => Scaffold(
        body: Container(
          
          child: Text("sdsd"),
        ),
      );
}

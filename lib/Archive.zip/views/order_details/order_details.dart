import 'package:flutter/material.dart';

class OrderDetails extends StatelessWidget {
  const OrderDetails({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Order Details'),
      ),
      body: SafeArea(
        child:  Text('data')
            
           
       
      )
    );
  }
}
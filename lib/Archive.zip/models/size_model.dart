class SizeModel {
  final String value;

  SizeModel({required this.value});
}